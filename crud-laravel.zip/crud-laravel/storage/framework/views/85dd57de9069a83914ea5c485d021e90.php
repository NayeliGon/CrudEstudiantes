


<?php $__env->startSection('title','Registrar Alumno| Escuela'); ?>

<?php $__env->startSection('contenido'); ?>


<main>

<div class="container py-4">
     <h2><?php echo e($msg); ?></h2>
     <a href="<?php echo e(url('alumnos')); ?>" class="btn btn-secondary">Regresar</a>

</div>
</main>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud-laravel\resources\views/alumnos/message.blade.php ENDPATH**/ ?>