

<?php $__env->startSection('title', 'Alumnos | Escuela'); ?>

<?php $__env->startSection('contenido'); ?>
<main>
   <div class="container py-4">
    <h2>Listado de Alumnos</h2>
    <a href="<?php echo e(url('alumnos/create')); ?>" class="btn btn-primary btn-sm">Nuevo Registro</a>
   <table class="table table-hover">
     <thead>
      <tr>
          <th>#</th>
          <th>Matricula</th>
          <th>Nombre</th>
          <th>Fecha Nacimiento</th>
          <th>Teléfono</th>
          <th>Email</th>
          <th>Nivel</th>
          <th></th>
          <th></th>
      </tr>
     </thead>
   
   <tbody>
      <?php $__currentLoopData = $alumnos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alumno): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>      
        <td><?php echo e($alumno->id); ?></td>
        <td><?php echo e($alumno->matricula); ?></td>
        <td><?php echo e($alumno->nombre); ?></td>
        <td><?php echo e($alumno->fecha_nacimiento); ?></td>
        <td><?php echo e($alumno->teléfono); ?></td>
        <td><?php echo e($alumno->email); ?></td>
        <td><?php echo e($alumno->nivel_id); ?></td>
        <td><a href="<?php echo e(url('alumnos/'.$alumno->id.'/edit')); ?>">Editar</a></td> <!-- Corregí el enlace "Editar" -->
        <td> 

            <form action="<?php echo e(url('alumnos/'.$alumno->id)); ?>" method="post">
               <?php echo method_field("DELETE"); ?>
               <?php echo csrf_field(); ?>
               <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
        </td>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   </tbody>
</table>
   </div>
</main>

<?php echo $__env->make('layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud-laravel\resources\views/alumnos/index.blade.php ENDPATH**/ ?>