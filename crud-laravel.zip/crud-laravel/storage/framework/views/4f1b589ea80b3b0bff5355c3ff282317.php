


<?php $__env->startSection('title','Registrar Alumno| Escuela'); ?>

<?php $__env->startSection('contenido'); ?>


<main>

<div class="container py-4">
     <h2>Registrar alumno</h2>
     <?php if($errors->any()): ?>
     <div class="alert alert-warning alert-dismissible fade show" role="alert">
          <ul>
             <?php $__currentLoopData = @erros->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <li><?php echo e($error); ?></li>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </ul>
          <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>



     <?php endif; ?>

<form action="<?php echo e(url('alumnos')); ?>" method="POST">
     <?php echo csrf_field(); ?>
  <div class="mb-3 row">
     <label for="matricula" class="col-sm-2 col-form-label">Matricula</label>
     <div class="col-sm-5">
         <input type="text" class="form-control" name="matricula" id="matricula" value="<?php echo e(old('matricula')); ?>" required>

     </div>
  </div>

  <div class="mb-3 row">
     <label for="nombre" class="col-sm-2 col-form-label">Nombre Completo</label>
     <div class="col-sm-5">
         <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo e(old('nombre')); ?>" required>

     </div>
  </div>


  <div class="mb-3 row">
     <label for="fecha" class="col-sm-2 col-form-label">Fecha de Nacimiento</label>
     <div class="col-sm-5">
         <input type="date" class="form-control" name="fecha" id="fecha" value="<?php echo e(old('fecha')); ?>" required>

     </div>
  </div>

  <div class="mb-3 row">
     <label for="telefono" class="col-sm-2 col-form-label">Telefono</label>
     <div class="col-sm-5">
         <input type="text" class="form-control" name="telefono" id="telefono" value="<?php echo e(old('telefono')); ?>" required>

     </div>
  </div>
 
  <div class="mb-3 row">
     <label for="email" class="col-sm-2 col-form-label">Email</label>
     <div class="col-sm-5">
         <input type="text" class="form-control" name="email" id="email" value="<?php echo e(old('email')); ?>">

     </div>
  </div>
  
  <div class="mb-3 row">
     <label for="nivel" class="col-sm-2 col-form-label">Nivel</label>
     <div class="col-sm-5">
         <select name="nivel" id="nivel" class="form-select" required>
             <option value="">Seleccionar nivel</option>
             <?php $__currentLoopData = $niveles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <option value="<?php echo e($nivel->id); ?>"><?php echo e($nivel->nombre); ?></option>
             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         </select>
     </div>
 </div>
 <a href="<?php echo e(url('alumnos')); ?>" class="btn btn-secondary">Regresar</a>
 <button type="submit" class="btn btn-success">Guardar</button>



 


</main>
<?php echo $__env->make('layout/template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\crud-laravel\resources\views/alumnos/create.blade.php ENDPATH**/ ?>